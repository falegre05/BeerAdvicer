package com.example.ferzi.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import org.semanticweb.HermiT.Reasoner;
import org.semanticweb.owlapi.apibinding.*;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.*;

import java.io.File;
import java.io.InputStream;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // First, we create an OWLOntologyManager object. The manager will load and save ontologies.
        OWLOntologyManager m = OWLManager.createOWLOntologyManager();
        // We use the OWL API to load the ontology.
        //File ontology = new File("ontologyv6.owl");
        InputStream ontology = getApplicationContext().getResources().openRawResource(R.raw.ontologyv6);

        try {
            OWLOntology ont = m.loadOntologyFromOntologyDocument(ontology);
            // Now, we instantiate HermiT by creating an instance of the Reasoner class in the package org.semanticweb.HermiT.
            OWLReasoner hermit = new Reasoner.ReasonerFactory().createReasoner(ont);
            // Finally, we output whether the ontology is consistent.
            System.out.println(hermit.isConsistent());
        }
        catch(OWLOntologyCreationException e){
            e.getStackTrace();
        }
    }
}
